// The key constants read as navigation keys in code; ktlint's property-naming rule would force
// SCREAMING_SNAKE_CASE for these compile-time constants.
@file:Suppress("ktlint:standard:property-naming")

package hrln.interactive.sidekit.design.input

import android.view.KeyEvent

/**
 * The navigation Sidekit's own screens move with, no matter which module is attached.
 *
 * Compose's focus system already moves on the D-pad and activates a focused control on Enter, and
 * Android treats [Back] ([KeyEvent.KEYCODE_BACK]) as "go back" everywhere. T9 and the Sundial send
 * exactly these keys natively, so they don't need help. The game controller and mini QWERTY send a
 * different set of keys (gamepad buttons, modifier keys), so [Keypad.translateForUi] rewrites
 * their native navigation keys to these canonical ones before anything else sees them. Back and
 * Options here mirror [SystemKeys].
 *
 * These are key codes, not a separate input layer: keeping them as real KeyEvents lets the rest of
 * Sidekit (T9Session, SidekitTextField, focus) keep working unchanged on the already-canonical
 * modules.
 */
object NavControls {
    const val Up = KeyEvent.KEYCODE_DPAD_UP
    const val Down = KeyEvent.KEYCODE_DPAD_DOWN
    const val Left = KeyEvent.KEYCODE_DPAD_LEFT
    const val Right = KeyEvent.KEYCODE_DPAD_RIGHT

    /** Select / open the focused control. [KeyEvent.KEYCODE_ENTER] is what T9 calls OK and ListItems act on. */
    const val Confirm = KeyEvent.KEYCODE_ENTER
    const val Back = KeyEvent.KEYCODE_BACK
    const val Options = KeyEvent.KEYCODE_ENDCALL

    /** Universal chrome actions the host handles (not focus movement). */
    const val Home = KeyEvent.KEYCODE_HOME
    const val Search = KeyEvent.KEYCODE_SEARCH

    /** Every canonical key, for contract tests. */
    val all = listOf(Up, Down, Left, Right, Confirm, Back, Options, Home, Search)

    /**
     * How each module's native keys map to canonical navigation, active while the module is
     * auto-detected and no text field owns the keypad (see [Keypad.translateForUi]).
     *
     * - T9 and the Sundial already send the canonical keys, so they map nothing.
     * - The game controller's D-pad is canonical too; A confirms and B goes back. X and Select
     *   open Options, Start goes Home and either shoulder opens Search. Y is handled by the SDK
     *   input loop as a direct jump to the action bar.
     * - Mini QWERTY: its bottom row is the modifier keys (SUGGEST / SYM / CASE = Ctrl / Alt /
     *   Shift) and its only dedicated directional control is a single up-down rocker (code 113),
     *   so navigation uses a cross of letter keys measured on-device: **T up, D left, B down,
     *   J right**. These are letters while a text field is focused and navigation keys when not
     *   (the session guard in [Keypad.translateForUi] chooses which). Enter is already Confirm.
     *   On a screen with a type-to-search field (the launcher, Apps, Phonebook, …) they stay
     *   letters, so every letter can start a search; there the rocker still moves up and down.
     */
    val defaultFor: Map<KeypadModule, Map<Int, Int>> = mapOf(
        KeypadModule.T9 to emptyMap(),
        KeypadModule.Sundial to emptyMap(),
        KeypadModule.GamePad to mapOf(
            KeyEvent.KEYCODE_BUTTON_A to Confirm,
            KeyEvent.KEYCODE_BUTTON_B to Back,
            KeyEvent.KEYCODE_BUTTON_X to Options,
            KeyEvent.KEYCODE_BUTTON_SELECT to Options,
            KeyEvent.KEYCODE_BUTTON_START to Home,
            KeyEvent.KEYCODE_BUTTON_L1 to Search,
            KeyEvent.KEYCODE_BUTTON_R1 to Search
        ),
        KeypadModule.Qwerty to mapOf(
            // Measured on-device: T / D / B / J around the tablet's centre form a directional cross.
            KeyEvent.KEYCODE_T to Up,
            KeyEvent.KEYCODE_D to Left,
            KeyEvent.KEYCODE_B to Down,
            KeyEvent.KEYCODE_J to Right
        )
    )

    /**
     * Hold actions for the Sundial's ring. A tap keeps the printed role (media, Tab, Enter); a
     * hold turns it into the navigation action the module has no dedicated key for. Tab/Enter have
     * no media role to preserve; Previous/Next keep theirs on a tap.
     */
    val sundialHoldFor: Map<Int, Int> = mapOf(
        KeyEvent.KEYCODE_TAB to Back,
        KeyEvent.KEYCODE_ENTER to Options,
        KeyEvent.KEYCODE_MEDIA_PREVIOUS to Left,
        KeyEvent.KEYCODE_MEDIA_NEXT to Right,
        KeyEvent.KEYCODE_DPAD_UP to Search,
        KeyEvent.KEYCODE_DPAD_DOWN to Home,
        // Some Sundial revisions report the bottom-right Enter key as the centre media key.
        // A hold still gives Confirm, while a tap keeps its media behaviour.
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE to Confirm,
        // Fallback for Options when Enter is that media key.
        KeyEvent.KEYCODE_DPAD_LEFT to Options
    )

    /** The canonical navigation key [code] becomes in [module]'s UI, or null to keep it as sent. */
    internal fun applyDefault(module: KeypadModule, code: Int): Int? = defaultFor[module]?.get(code)
}
